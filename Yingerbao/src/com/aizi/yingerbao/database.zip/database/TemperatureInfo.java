package com.aizi.yingerbao.database;

public class TemperatureInfo {
    public long mTemperatureTimestamp = 0;
    public String mTemperatureValue;
    public int mTemperatureYear = 0;
    public int mTemperatureMonth = 0;
    public int mTemperatureDay = 0;
    public int mTemperatureMinute = 0;
}
