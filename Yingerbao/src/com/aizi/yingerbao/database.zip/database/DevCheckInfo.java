package com.aizi.yingerbao.database;

public class DevCheckInfo {
    public int mNoSyncDataLength = 0;
    public int mDeviceCharge = 0; // 电量
    public byte mDeviceStatus;
    
    public int mCheckInfoYear = 0;
    public int mCheckInfoMonth = 0;
    public int mCheckInfoDay = 0;
    public int mCheckInfoHour = 0;
    public int mCheckInfoMinute = 0;
    public int mCheckInfoSecond = 0;

}
