package com.aizi.yingerbao.database;

public class BreathStopInfo {
    public long mBreathTimestamp = 0;
    public int mBreathIsAlarm = 0;
    public int mBreathDuration = 0;
    
    public int mBreathYear = 0;
    public int mBreathMonth = 0;
    public int mBreathDay = 0;
    public int mBreathHour = 0;
    public int mBreathMinute = 0;
    public int mBreathSecond = 0;
}
