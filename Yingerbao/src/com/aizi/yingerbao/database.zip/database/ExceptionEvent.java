package com.aizi.yingerbao.database;

public class ExceptionEvent {

    public int mExceptionType = 0;
    public int mExceptionData1 = 0;
    public int mExceptionData2 = 0;
    public int mExceptionData3 = 0;
    
    public int mExceptionYear = 0;
    public int mExceptionMonth = 0;
    public int mExceptionDay = 0;
    public int mExceptionHour = 0;
    public int mExceptionMinute = 0;
    public int mExceptionSecond = 0;
}
