package com.aizi.yingerbao.database;

public class SleepInfo {
    public long mSleepTimestamp = 0;
    public int mSleepYear = 0;
    public int mSleepMonth = 0;
    public int mSleepDay = 0;
    public int mSleepMinute = 0;
    public int mSleepValue = 0;
}
