/** Automatically generated file. DO NOT MODIFY */
package com.xzj.babyfun;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}